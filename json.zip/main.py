import module
url='http://coreyms.com'
module.fun(url)
