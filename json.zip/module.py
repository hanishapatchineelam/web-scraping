from bs4 import BeautifulSoup
import requests
import json
import codecs

def fun(url):
    
    page = requests.get(url).text
    
    s=json.dumps(page)
    
    soup = BeautifulSoup(page, 'html.parser')


    # with open('data.json', 'w+') as json_file:
    #     data=json.load(json_file)


     
    #     data(['header', 'summary', 'video_link'])

        #{header, summary, video_link}
    

    data = {}
    data['header'] = []
    data['summary'] = []
    data['video_link'] = []


    for article in soup.find_all('article'):
        
        header = article.h2.a.text
        
        print(header)

        data['header'].append(header)
        

        text = article.find('div', class_='entry-content').p.text
        
        print(text)
        data['summary'].append(text)
  

    try:
        
        vid_src = article.find('iframe', class_='youtube-player')['src']

        vid_id = vid_src.split('/')[4]
        vid_id = vid_id.split('?')[0]

        yt_link = 'https://youtube.com/watch?v={vid_id}'
    except Exception as e:
        yt_link = None

    print(yt_link)

    data['video_link'].append(yt_link)

    print()


    print("data")

    with codecs.open('data.txt', 'w', encoding='utf-8') as outfile:
        json.dump(data, outfile, ensure_ascii=False)


    
